import { CourseSortPipe } from './course-sort.pipe';

describe('CourseSortPipe', () => {
  it('create an instance', () => {
    const pipe = new CourseSortPipe();
    expect(pipe).toBeTruthy();
  });
});
