import { Pipe, PipeTransform } from '@angular/core';
import * as _ from 'lodash';

@Pipe({
  name: 'courseSort'
})
export class CourseSortPipe implements PipeTransform {

  transform(value: any[], field : string): any[] {
    return _.orderBy(value, field);
  }

}
