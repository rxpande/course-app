import { CourseTimePipePipe } from './course-time-pipe.pipe';

describe('CourseTimePipePipe', () => {
  it('create an instance', () => {
    const pipe = new CourseTimePipePipe();
    expect(pipe).toBeTruthy();
  });
});
