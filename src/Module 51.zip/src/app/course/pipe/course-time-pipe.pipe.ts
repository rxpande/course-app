import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'courseTimePipe'
})
export class CourseTimePipePipe implements PipeTransform {
  transform(minutes: number): string {
    if(minutes>59){
      let hours = Math.floor(minutes / 60);
      let min = minutes % 60;
      return `${hours}h ${min}min`;
    }  
    else{
      return `${minutes}min`;
    }
    }
}
