import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CourseSearchComponent } from './course-search/course-search.component';
import { CourseAddComponent } from './course-add/course-add.component';
import { CourseListComponent } from './course-list/course-list.component';
import { CoursePlateBorderDirective } from './directive/course-plate-border.directive';
import { CourseTimePipePipe } from './pipe/course-time-pipe.pipe';
import { CourseSortPipe } from './pipe/course-sort.pipe';

@NgModule({
  declarations: [
    CourseSearchComponent,
    CourseAddComponent,
    CourseListComponent,
    CoursePlateBorderDirective,
    CourseTimePipePipe,
    CourseSortPipe,
  ],
  imports: [
    CommonModule,
    FormsModule
  ],
  exports: [
    CourseSearchComponent,
    CourseAddComponent,
    CourseListComponent,
  ]
})
export class CourseModule { }
