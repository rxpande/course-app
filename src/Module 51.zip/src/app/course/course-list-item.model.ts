export interface CourseListItem {
    id: number;
    title: string;
    description: string;
    creationDate: string;
    durationMinutes: number;
    topRated: boolean;
}
