import { Component, OnInit } from '@angular/core';
import { CourseService } from '../course.service';
import { CourseListItem } from '../course-list-item.model';

@Component({
  selector: 'app-course-add',
  templateUrl: './course-add.component.html'
})
export class CourseAddComponent implements OnInit {

  constructor(private courseService: CourseService) {}

  ngOnInit() {
  }

  addCourse() {
    const courseData: CourseListItem = {
      id: 5,
      title: 'Test Title',
      description: 'Created by Service',
      creationDate: 'Sun Oct 20 2019 18:08:15 GMT+0530',
      durationMinutes: 260,
      topRated: true,
    }
    this.courseService.createCourse( courseData );
  }

}
