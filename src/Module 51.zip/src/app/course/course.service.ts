import { Injectable } from '@angular/core';
import { CourseListItem } from './course-list-item.model';

@Injectable({
  providedIn: 'root'
})
export class CourseService {

  constructor() { }

  getCourseItems(): CourseListItem[] {
    return [
      {
        id: 1,
        title: 'MongoDB',
        description: 'Very GOod',
        creationDate: 'Sun Oct 20 2019 18:08:15 GMT+0530',
        durationMinutes: 180,
        topRated: true
      },
      {
        id: 2,
        title: 'ExpressJS',
        description: 'Very GOod',
        creationDate: 'Sun Oct 20 2019 18:08:15 GMT+0530',
        durationMinutes: 180,
        topRated: false
      },
      {
        id: 3,
        title: 'Angular',
        description: 'Very GOod',
        creationDate: 'Sun Oct 20 2019 18:08:15 GMT+0530',
        durationMinutes: 180,
        topRated: true
      },
      {
        id: 4,
        title: 'React JS',
        description: 'Very GOod',
        creationDate: 'Sun Oct 20 2019 18:08:15 GMT+0530',
        durationMinutes: 180,
        topRated: false
      },
    ];
  }

  createCourse( data: any ) {
    console.log("TCL: CourseService -> createCourse -> data", data)
  }

  getCourseById( id: number ) {
    console.log("TCL: CourseService -> getCourseById -> id", id)
  }

  updateCourse( data: any ) {
    console.log("TCL: CourseService -> updateCourse -> data", data)
  }

  removeCourse( id: number ) {
    console.log("TCL: CourseService -> removeCourse -> id", id)
  }
}
