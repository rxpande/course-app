import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { LoginService } from './login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  isSubmitted  =  false;

  constructor(private loginService: LoginService, private formBuilder: FormBuilder ) { }
  
  ngOnInit() {
    this.loginForm  =  this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  login() {
    console.log("TCL: LoginComponent -> login -> logged in successfully");
    this.loginService.login(this.loginForm.value)
  }

  logout() {
    this.loginService.logout();
  }

  isAuthenticated() {
    console.log("TCL: LoginComponent -> isAuthenticated -> this.loginService.isAuthenticted();", this.loginService.isAuthenticted());
  }

  getUserInfo() {
    console.log("TCL: LoginComponent -> getUserInfo -> this.loginService.getUserInfo()", this.loginService.getUserInfo())
  }

}
