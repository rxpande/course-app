import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  loggedIn: boolean = false;

  constructor() { }

  login( user ) {
    console.log("TCL: LoginService -> login -> user", user)
    localStorage.setItem('ACCESS_TOKEN', user.username + user.password);
  }

  isAuthenticted() {
    return localStorage.getItem('ACCESS_TOKEN') !== null;
  }

  logout() {
    localStorage.removeItem('ACCESS_TOKEN');
  }

  getUserInfo() {
    return localStorage.getItem('ACCESS_TOKEN');
  }
}
